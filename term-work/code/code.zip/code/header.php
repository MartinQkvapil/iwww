<ul>

    <li><a class="<?php if($currentPage =='home'){echo 'active';}?>" href="<?= BASE_URL ?>">Home</a></li>
    <li><a class="<?php if($currentPage =='kampelicka'){echo 'active';}?>" href="<?= BASE_URL . "?page=kampelicka" ?>">Kampelička</a></li>
    <li><a  href="<?= BASE_URL . "?page=Kontakt" ?>">Kontakt</a></li>
    <li><a  href="<?= BASE_URL . "?page=Akce" ?>">Akce</a></li>
    <?php if (Authentication::getInstance()->hasIdentity()) : ?>
        <!-- <a href="<?= BASE_URL . "?page=user&action=read-all" ?>">Read all user</a> -->
        <!-- <a href="<?= BASE_URL . "?page=user&action=by-email" ?>">By email</a> -->
        <a href="<?= BASE_URL . "?page=logout" ?>">Logout</a>

        <?php if($opravneni=='admin'): ?>
            <li><a href="<?= BASE_URL . "?./page/crud=uzivatele" ?>">Login</a></li>
        <?php else : ?>
            <li><a href="<?= BASE_URL . "?page=uzivatel" ?>">ZP-Uzivatelů</a></li>
            <li><a href="<?= BASE_URL . "?page=udalost" ?>">Událost</a></li>
            <li><a href="<?= BASE_URL . "?page=listek" ?>">Lístky</a></li>
            <li><a href="<?= BASE_URL . "?page=mistnost" ?>">Místnost</a></li>
            <li><a href="<?= BASE_URL . "?page=mistnost" ?>">Vybavení</a></li>
        <?php endif; ?>
    <?php else : ?>
        <li><a href="<?= BASE_URL . "?page=login" ?>">Login</a></li>
        <li><a href="<?= BASE_URL . "?page=registrace" ?>">Registrace</a></li>
    <?php endif; ?>
</ul>