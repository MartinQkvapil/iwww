<html>
<head>
    <title>Registrace</title>
</head>
<body>
<FORM ACTION="register.php" METHOD="POST">
    <h1>Registrace</h1>

    <table>
        <tr>
            <td>User Name :</td>
            <td><input name="regname" type="text" size"20"></input></td>
        </tr>
        <tr>
            <td>email :</td>
            <td><input name="regemail" type="text" size"20"></input></td>
        </tr>
        <tr>
            <td>password :</td>
            <td><input name="regpass1" type="password" size"20"></input></td>
        </tr>
        <tr>
            <td>retype password :</td>
            <td><input name="regpass2" type="password" size"20"></input></td>
        </tr>
    </table>
    <input type="submit" value="register me!"></input>
</FORM>
</body>
</html>


<?php
session_start();
if ($_POST["regname"] && $_POST["regemail"] && $_POST["regpass1"] && $_POST["regpass2"]) {
    if ($_POST["regpass1"] == $_POST["regpass2"]) {
        include 'config/database.php';
        try {
           /* $sql = "insert into users (UserName,UserEmail,Password)values('$_POST[regname]','$_POST[regemail]','$_POST[regpass1]')";
           // $result = mysql_query($sql, $conn) or die(mysql_error());
            $stmt = $con->prepare($sql);
            $stmt->execute();
            print "<h1>you have registered sucessfully</h1>";*/
        } catch
        (PDOException $exception) {
            die('ERROR: ' . $exception->getMessage());
        }
        print "<a href='main_login.php'>go to login page</a>";
    } else print "passwords doesnt match";
} else print"invaild input data";
?>