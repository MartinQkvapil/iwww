<h1>Uzivatel</h1>
<?php
if ($_GET["action"] == "read-all") {
    echo "<h2>All users</h2>";
    $userDao = new UserRepository(Connection::getPdoInstance());
    $allUsersResult = $userDao->getAllUsers();

    $datatable = new DataTable($allUsersResult);
    $datatable->addColumn("iduzivatel", "ID");
    $datatable->addColumn("email", "Email");
    $datatable->addColumn("jmeno", "Jmeno");
    $datatable->render();

} else if ($_GET["action"] == "by-email") {
    echo "<h2>By email</h2>";
    ?>

    <form method="post">
        <input type="text" name="mail" placeholder="insert email address">
        <input type="submit" value="Find by email">
    </form>

    <?php

    if (!empty($_POST["mail"])) {
        $userDao = new UserRepository(Connection::getPdoInstance());
        $usersByEmail = $userDao->getByEmail($_POST["mail"]);
        $datatable = new DataTable($usersByEmail);
        $datatable->addColumn("iduzivatel", "ID");
        $datatable->addColumn("email", "Email");
        $datatable->addColumn("jmeno", "Jmeno");
        $datatable->render();
    }

} else if ($_GET["action"] == "read-one") {
    echo "<h2>read</h2>";
    // existuje záznam? s timto id?
    // isset() is a PHP function used to verify if a value is there or not

    $id = isset($_GET['id']) ? $_GET['id'] : die('ERROR: Record ID not found.');

    //propojení s databazi
    include 'config/database.php';
    // čti data o uživateli
    try {
        // připrav select
        //SELECT idUzivatel, jmeno, prijmeni, email, roleUzivatele FROM uzivatel ORDER BY idUzivatel DESC"
        $query = "SELECT idUzivatel, jmeno, heslo, email, roleUzivatele FROM uzivatel WHERE idUzivatel = ? LIMIT 0,1";
        $stmt = $con->prepare($query);

        // this is the first question mark
        $stmt->bindParam(1, $id);

        // execute our query
        $stmt->execute();

        // store retrieved row to a variable
        $row = $stmt->fetch(PDO::FETCH_ASSOC);

        // hodnoty k naplneni formulaře
        $idUzivatel = $row['idUzivatel'];
        $name = $row['jmeno'];
        $heslo = $row['heslo'];
        $email = $row['email'];
        $role = $row['roleUzivatele'];
    } // show error
    catch (PDOException $exception) {
        die('ERROR: ' . $exception->getMessage());
    }

    ?>
    <!--we have our html table here where the record will be displayed-->
    <table class='table table-hover table-responsive table-bordered'>
        <tr>
            <td>id</td>
            <td><?php echo htmlspecialchars($idUzivatel, ENT_QUOTES); ?></td>
        </tr>
        <tr>
            <td>jmeno</td>
            <td><?php echo htmlspecialchars($name, ENT_QUOTES); ?></td>
        </tr>
        <tr>
            <td>heslo</td>
            <td><?php echo htmlspecialchars($heslo, ENT_QUOTES); ?></td>
        </tr>
        <tr>
            <td>email</td>
            <td><?php echo htmlspecialchars($email, ENT_QUOTES); ?></td>
        </tr>
        <tr>
            <td>role</td>
            <td><?php echo htmlspecialchars($role, ENT_QUOTES); ?></td>
        </tr>
        <tr>
            <td></td>
            <td>
                <a href='?page=uzivatel' class='btn btn-danger'>Zobraz všechny uživatele</a>
            </td>
        </tr>
    </table>
    <?php


} else if ($_GET["action"] == "edit") {
    echo "<h2>read</h2>";
    // existuje záznam? s timto id?
    // isset() is a PHP function used to verify if a value is there or not

    $id = isset($_GET['id']) ? $_GET['id'] : die('ERROR: Record ID not found.');

    //propojení s databazi
    include 'config/database.php';
    // čti data o uživateli
    try {
        // připrav select
        //SELECT idUzivatel, jmeno, prijmeni, email, roleUzivatele FROM uzivatel ORDER BY idUzivatel DESC"
        $query = "SELECT idUzivatel, jmeno, heslo, email, roleUzivatele FROM uzivatel WHERE idUzivatel = ? LIMIT 0,1";
        $stmt = $con->prepare($query);

        // this is the first question mark
        $stmt->bindParam(1, $id);

        // execute our query
        $stmt->execute();

        // store retrieved row to a variable
        $row = $stmt->fetch(PDO::FETCH_ASSOC);

        // hodnoty k naplneni formulaře
        $idUzivatel = $row['idUzivatel'];
        $name = $row['jmeno'];
        $heslo = $row['heslo'];
        $email = $row['email'];
        $role = $row['roleUzivatele'];
    } // show error
    catch (PDOException $exception) {
        die('ERROR: ' . $exception->getMessage());
    }

    ?>
    <!--we have our html table here where the record will be displayed-->
    <table class='table table-hover table-responsive table-bordered'>
        <tr>
            <td>id</td>
            <td><?php echo htmlspecialchars($idUzivatel, ENT_QUOTES); ?></td>
        </tr>
        <tr>
            <td>jmeno</td>
            <td><?php echo htmlspecialchars($name, ENT_QUOTES); ?></td>
        </tr>
        <tr>
            <td>heslo</td>
            <td><?php echo htmlspecialchars($heslo, ENT_QUOTES); ?></td>
        </tr>
        <tr>
            <td>email</td>
            <td><?php echo htmlspecialchars($email, ENT_QUOTES); ?></td>
        </tr>
        <tr>
            <td>role</td>
            <td><?php echo htmlspecialchars($role, ENT_QUOTES); ?></td>
        </tr>
        <tr>
            <td></td>
            <td>
                <a href='?page=uzivatel' class='btn btn-danger'>Zobraz všechny uživatele</a>
            </td>
        </tr>
    </table>
    <?php


} else if ($_GET["action"] == "delete") {
    include '../config/database.php';

    try {

        // get record ID
        // isset() is a PHP function used to verify if a value is there or not
        $id=isset($_GET['id']) ? $_GET['id'] : die('ERROR: Record ID not found.');

        // delete query
        $query = "DELETE FROM uzivatel WHERE idUzivatel = ?";
        $stmt = $con->prepare($query);
        $stmt->bindParam(1, $id);

        if($stmt->execute()){
            // redirect to read records page and
            // tell the user record was deleted
            header('Location: uzivatel.php?action=deleted');
        }else{
            die('Unable to delete record.');
        }
    }

// show error
    catch(PDOException $exception){
        die('ERROR: ' . $exception->getMessage());
    }



}

?>
