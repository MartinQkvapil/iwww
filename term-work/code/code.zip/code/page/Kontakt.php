<?php
?>

<h1>Kontakt</h1>

PO - 17,30 - 22,00 hod.
ÚT - 17.30 - 22.00 hod.
ST - 17,30 - 22,00 hod.
ČT - 17,30 - 22,00 hod.
PÁ - 17.30 - 22,00 hod.
SO - ZAVŘENO
NE -   9,30 - 12,00 hod.
16,30 - 23,00 hod.