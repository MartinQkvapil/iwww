<?php
ob_start();
session_start();
include 'config.php';


function __autoload($className)
{
    if (file_exists('./class/' . $className . '.php')) {
        require_once './class/' . $className . '.php';
        return true;
    }
    return false;
}

?>

<!DOCTYPE html>
<html lang="cs">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="css/styl.css" type="text/css">
    <title>Kampelička Letohrad</title>
</head>
<body>
<header>

    <div class="header" id="wrapper">

        <div id="first">
            <div id="logo"></div>
            <h1 id="header_text">Kampelička Letohrad</h1>
        </div>
        <div id=second>
            <div id=prihlaseni>Něco přidej</div>
        </div>
    </div>

</header>
<div class="body_div">
    <nav class="menu">
        <?php
        $currentPage = 'home';
        include('header.php'); ?>
    </nav>

    <main>
        <?php

        $file = null;
        if (isset($_GET['page'])) {
            $file = "./page/" . $_GET['page'] . ".php";
            $currentPage =  $_GET['page'];
            echo $currentPage;
        }
        if (file_exists($file)) {
            include $file;
        } else {
            $tmp = Authentication::getInstance()->getIdentity();
            echo "<h1>Vítejte:</h1>" . $tmp['email'];
            $conn = Connection::getPdoInstance();
            $obj = new UserRepository($conn);
            //echo $obj->getAllUsers()[0]['email'];
           // echo print_r( $obj->getAllUsers());
        }


        ?>
    </main>


</div>


</body>
</html>