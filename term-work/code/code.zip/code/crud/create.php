<!DOCTYPE HTML>
<html>
<head>
    <title> Vytvor uzivatel </title>

    <!-- Latest compiled and minified Bootstrap CSS
     <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" />-->

</head>
<body>
<div class="container">
    <div class="page-header">
        <h1>Vytvor uzivatel</h1>
    </div>

    <?php
    if($_POST){

        // include database connection
        include 'config/database.php';

        try{

            // insert query
            $query = "INSERT INTO uzivatel SET iduzivatel=:iduzivatel, jmeno=:jmeno, prijmeni=:prijmeni, email=:email,
             datumPridani=:datumPridani, roleUzivatele=:roleUzivatele";

            // prepare query for execution
            $stmt = $con->prepare($query);

            // posted values
            $iduzivatel=htmlspecialchars(strip_tags($_POST['iduzivatel']));
            $jmeno=htmlspecialchars(strip_tags($_POST['jmeno']));
            $prijmeni=htmlspecialchars(strip_tags($_POST['prijmeni']));
            $email=htmlspecialchars(strip_tags($_POST['email']));
            $datumPridani=htmlspecialchars(strip_tags($_POST['datumPridani']));
            $roleUzivatele=htmlspecialchars(strip_tags($_POST['roleUzivatele']));

            /*$description=htmlspecialchars(strip_tags($_POST['description']));
            $price=htmlspecialchars(strip_tags($_POST['price']));*/

            // bind the parameters
            $stmt->bindParam(':iduzivatel', $iduzivatel);
            $stmt->bindParam(':jmeno', $jmeno);
            $stmt->bindParam(':prijmeni', $prijmeni);
            $stmt->bindParam(':email', $email);
            $stmt->bindParam(':datumPridani', $datumPridani);
            $stmt->bindParam(':roleUzivatele', $roleUzivatele);

            $iduzivatel = NULL;
            $datumPridani = '';
            /*
            $stmt->bindParam(':description', $description);
            $stmt->bindParam(':price', $price);*/

            // specify when this record was inserted to the database
            $datumPridani=date('Y-m-d H:i:s');
            $stmt->bindParam(':datumPridani', $datumPridani);

            // Execute the query
            if($stmt->execute()){
                echo "<div class='alert alert-success'>Nový uzivatel ulozen</div>";
            }else{
                echo "<div class='alert alert-danger'>Nelze ulozit uzivatele</div>";
            }

        }

            // show error
        catch(PDOException $exception){
            die('ERROR: ' . $exception->getMessage());
        }
    }
    ?>

    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="post">
        <table class='table table-hover table-responsive table-bordered'>
            <tr>
                <td>id</td>
                <td><input type='text' name='iduzivatel' class='form-control' /></td>
            </tr>
            <tr>
                <td>jmeno</td>
                <td><input type='text' name='jmeno' class='form-control' /></td>
            </tr>
            <tr>
                <td>prijmeni</td>
                <td><input type='text' name='prijmeni' class='form-control' /></td>
            </tr>
            <tr>
                <td>email</td>
                <td><input type='text' name='email' class='form-control' /></td>
            </tr>
            <tr>
                <td>date</td>
                <td><input type='text' name='datumPridani' class='form-control' /></td>
            </tr>
            <tr>
                <td>role</td>
                <td><input type='text' name='roleUzivatele' class='form-control' /></td>
            </tr>
            <tr>
                <td></td>
                <td>
                    <input type='submit' value='Uložit' class='btn btn-primary' />
                    <a href='../page/uzivatel.php' class='btn btn-danger'>Zpět na všechny uživatele</a>
                </td>
            </tr>
        </table>
    </form>

</div> <!-- end .container -->

<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<!-- <script src="https://code.jquery.com/jquery-3.2.1.min.js"></script> -->

<!-- Latest compiled and minified Bootstrap JavaScript -->
<!-- <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script> -->

</body>
</html>