<!DOCTYPE HTML>
<html>
<head>
    <title>Zobraz jednoho</title>
    <!-- Latest compiled and minified Bootstrap CSS -->
    <!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" /> -->
</head>
<body>
    <!-- container -->
    <div class="container">
        <div class="page-header">
            <h1>Zobraz uzivatele</h1>
        </div>

        <?php
        // existuje záznam? s timto id?
        // isset() is a PHP function used to verify if a value is there or not
        $id=isset($_GET['id']) ? $_GET['id'] : die('ERROR: Record ID not found.');

        //propojení s databazi
        include 'config/database.php';

        // čti data o uživateli
        try {
            // připrav select
            //SELECT idUzivatel, jmeno, prijmeni, email, roleUzivatele FROM uzivatel ORDER BY idUzivatel DESC"
            $query = "SELECT idUzivatel, jmeno, prijmeni, email, roleUzivatele FROM uzivatel WHERE idUzivatel = ? LIMIT 0,1";
            $stmt = $con->prepare( $query );

            // this is the first question mark
            $stmt->bindParam(1, $id);

            // execute our query
            $stmt->execute();

            // store retrieved row to a variable
            $row = $stmt->fetch(PDO::FETCH_ASSOC);

            // hodnoty k naplneni formulaře
            $idUzivatel = $row['idUzivatel'];
            $name = $row['jmeno'];
            $surname = $row['prijmeni'];
            $email = $row['email'];
            $role = $row['roleUzivatele'];
        }

// show error
        catch(PDOException $exception){
            die('ERROR: ' . $exception->getMessage());
        }
        ?>

        <!--we have our html table here where the record will be displayed-->
        <table class='table table-hover table-responsive table-bordered'>
            <tr>
                <td>id</td>
                <td><?php echo htmlspecialchars($idUzivatel, ENT_QUOTES);  ?></td>
            </tr>
            <tr>
                <td>jmeno</td>
                <td><?php echo htmlspecialchars($name, ENT_QUOTES);  ?></td>
            </tr>
            <tr>
                <td>prijmeni</td>
                <td><?php echo htmlspecialchars($surname, ENT_QUOTES);  ?></td>
            </tr>
            <tr>
                <td>email</td>
                <td><?php echo htmlspecialchars($email, ENT_QUOTES);  ?></td>
            </tr>
            <tr>
                <td>role</td>
                <td><?php echo htmlspecialchars($role, ENT_QUOTES);  ?></td>
            </tr>
            <tr>
                <td></td>
                <td>
                    <a href='../page/uzivatel.php' class='btn btn-danger'>Zobraz všechny uživatele</a>
                </td>
            </tr>
        </table>

    </div> <!-- end .container -->

<!-- jQuery (necessary for Bootstrap's JavaScript plugins)
<script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>-->

<!-- Latest compiled and minified Bootstrap JavaScript
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>-->

</body>
</html>